[Appearance]
EmojiFont=Noto Color Emoji,19,-1,5,400,0,0,0,0,0,0,0,0,0,0,1
Font=MesloLGS NF,15,-1,5,400,0,0,0,0,0,0,0,0,0,0,1
LineSpacing=0

[General]
Command=/bin/zsh
Name=Profile 1
Parent=FALLBACK/
TerminalCenter=true
TerminalMargin=5
