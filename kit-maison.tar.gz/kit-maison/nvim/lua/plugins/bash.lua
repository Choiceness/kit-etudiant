-- Scripts bash : serveur de langage (complétion, doc) + shellcheck (erreurs). shfmt formate déjà.
return {
  { "neovim/nvim-lspconfig", opts = { servers = { bashls = {} } } },
  { "mfussenegger/nvim-lint", opts = { linters_by_ft = { sh = { "shellcheck" }, bash = { "shellcheck" } } } },
}
