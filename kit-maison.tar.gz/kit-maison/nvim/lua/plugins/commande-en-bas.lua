-- Ligne de commande et messages classiques de Neovim, en bas de l'écran (noice ne les gère plus)
-- Pour revenir à noice : supprimer ce fichier.
return {
  { "folke/noice.nvim", opts = { cmdline = { enabled = false }, messages = { enabled = false } } },
}
